
#import "wst.h" // use this for 2005/12 WS-Trust
// #import "wst2.h" // use this for 2005/02 WS-Trust

